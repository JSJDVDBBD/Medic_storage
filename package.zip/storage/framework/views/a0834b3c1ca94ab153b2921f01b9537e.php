<!-- resources/views/corte-caja/index.blade.php -->


<?php $__env->startSection('title', 'Corte de Caja'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Corte de Caja</h1>
        <a href="<?php echo e(route('corte-caja.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
            Nuevo Corte
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Efectivo</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Transferencia</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Diferencia</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registrado por</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $cortes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($corte->fecha->format('d/m/Y')); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">$<?php echo e(number_format($corte->ventas_efectivo, 2)); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">$<?php echo e(number_format($corte->ventas_transferencia, 2)); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">$<?php echo e(number_format($corte->total_ventas, 2)); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="<?php echo e($corte->diferencia < 0 ? 'text-red-600' : 'text-green-600'); ?>">
                            $<?php echo e(number_format($corte->diferencia, 2)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($corte->usuario->name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Proyecto\medic-storage\resources\views/corte-caja/index.blade.php ENDPATH**/ ?>