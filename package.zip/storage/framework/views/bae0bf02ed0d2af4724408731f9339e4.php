<!-- resources/views/alertas/index.blade.php -->


<?php $__env->startSection('title', 'Alertas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-6">Alertas</h1>

    <!-- Alertas por caducidad -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div class="bg-orange-500 text-white px-6 py-3">
            <h2 class="text-lg font-semibold">Medicamentos próximos a caducar</h2>
        </div>
        <div class="p-6">
            <?php if($alertasCaducidad->isEmpty()): ?>
                <p class="text-gray-500">No hay medicamentos próximos a caducar.</p>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Días para caducar</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha Caducidad</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $alertasCaducidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($medicamento->nombre); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 rounded-full 
                                    <?php if($medicamento->fecha_caducidad->diffInDays(now()) <= 7): ?> bg-red-100 text-red-800
                                    <?php elseif($medicamento->fecha_caducidad->diffInDays(now()) <= 15): ?> bg-orange-100 text-orange-800
                                    <?php else: ?> bg-yellow-100 text-yellow-800
                                    <?php endif; ?>">
                                    <?php echo e($medicamento->fecha_caducidad->diffInDays(now())); ?> días
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($medicamento->fecha_caducidad->format('d/m/Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Alertas por stock bajo -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="bg-red-500 text-white px-6 py-3">
            <h2 class="text-lg font-semibold">Medicamentos con stock bajo</h2>
        </div>
        <div class="p-6">
            <?php if($alertasStock->isEmpty()): ?>
                <p class="text-gray-500">No hay medicamentos con stock bajo.</p>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock actual</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $alertasStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($medicamento->nombre); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 rounded-full bg-red-100 text-red-800">
                                    <?php echo e($medicamento->cantidad); ?> unidades
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="<?php echo e(route('medicamentos.edit', $medicamento->id)); ?>" class="text-blue-600 hover:text-blue-900">
                                    Reabastecer
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\medic-storage\medic-storage\resources\views/alertas/index.blade.php ENDPATH**/ ?>