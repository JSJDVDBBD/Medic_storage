

<?php $__env->startSection('title', 'Medicamentos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 class="text-2xl font-bold flex items-center">
            <i class="fas fa-pills mr-2"></i> Medicamentos
        </h1>
        
        <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
            <a href="<?php echo e(route('medicamentos.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center justify-center">
                <i class="fas fa-plus mr-2"></i> Nuevo Medicamento
            </a>
            
            <form action="<?php echo e(route('medicamentos.index')); ?>" method="GET" class="flex">
                <input type="text" name="search" placeholder="Buscar..." value="<?php echo e(request('search')); ?>"
                    class="px-4 py-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full">
                <button type="submit" class="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded-r-lg">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-4 border-b flex flex-col sm:flex-row justify-between items-start sm:items-center bg-gray-50">
            <div class="flex space-x-2 mb-2 sm:mb-0">
                <a href="<?php echo e(route('medicamentos.index', ['stock' => 'bajo'])); ?>" 
                    class="px-3 py-1 rounded-full text-sm font-medium <?php echo e(request('stock') == 'bajo' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'); ?>">
                    Stock Bajo
                </a>
                <a href="<?php echo e(route('medicamentos.index', ['caducidad' => 'proxima'])); ?>" 
                    class="px-3 py-1 rounded-full text-sm font-medium <?php echo e(request('caducidad') == 'proxima' ? 'bg-orange-100 text-orange-800' : 'bg-gray-100 text-gray-800'); ?>">
                    Próximos a Caducar
                </a>
                <a href="<?php echo e(route('medicamentos.index')); ?>" 
                    class="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                    Todos
                </a>
            </div>
            
            <div class="text-sm text-gray-600">
                Mostrando <?php echo e($medicamentos->firstItem()); ?> - <?php echo e($medicamentos->lastItem()); ?> de <?php echo e($medicamentos->total()); ?> registros
            </div>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Imagen</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Presentación</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Venta</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Caducidad</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $fechaCaducidad = \Carbon\Carbon::parse($medicamento->fecha_caducidad);
                        $diasParaCaducar = $fechaCaducidad->diffInDays(now(), false) * -1;
                    ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <img src="<?php echo e($medicamento->imagen_url); ?>" alt="<?php echo e($medicamento->nombre); ?>" class="h-10 w-10 rounded-full object-cover">
                        </td>
                        <td class="px-6 py-4">
                            <div class="font-medium text-gray-900"><?php echo e($medicamento->nombre); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($medicamento->laboratorio); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php echo e($medicamento->presentacion); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <span class="font-medium <?php echo e($medicamento->stock <= $medicamento->stock_minimo ? 'text-red-600' : 'text-gray-900'); ?>">
                                    <?php echo e($medicamento->stock); ?>

                                </span>
                                <span class="text-xs text-gray-500 ml-1">/ <?php echo e($medicamento->stock_minimo); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="font-medium">$<?php echo e(number_format($medicamento->precio_venta, 2)); ?></span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs rounded-full 
                                <?php echo e($diasParaCaducar <= 0 ? 'bg-red-100 text-red-800' : 
                                  ($diasParaCaducar <= 30 ? 'bg-orange-100 text-orange-800' : 'bg-green-100 text-green-800')); ?>">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                (<?php echo e($diasParaCaducar <= 0 ? 'Caducado' : $fechaCaducidad->diffForHumans()); ?>)
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex space-x-2">
                                <a href="<?php echo e(route('medicamentos.show', $medicamento->id)); ?>" 
                                    class="text-blue-600 hover:text-blue-900" title="Ver">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('medicamentos.edit', $medicamento->id)); ?>" 
                                    class="text-yellow-600 hover:text-yellow-900" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('medicamentos.destroy', $medicamento->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-900" 
                                        onclick="return confirm('¿Estás seguro de eliminar este medicamento?')" title="Eliminar">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                            No se encontraron medicamentos
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="bg-gray-50 px-4 py-3 border-t">
            <?php echo e($medicamentos->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\medic-storage\medic-storage\resources\views/medicamentos/index.blade.php ENDPATH**/ ?>