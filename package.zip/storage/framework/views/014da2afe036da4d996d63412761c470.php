

<?php $__env->startSection('title', 'Detalle de Medicamento'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-6 bg-gray-50 border-b flex justify-between items-center">
            <div>
                <h2 class="text-xl font-semibold flex items-center">
                    <i class="fas fa-pills mr-2"></i> Detalle de Medicamento
                </h2>
                <p class="text-sm text-gray-600 mt-1">Código: <?php echo e($medicamento->codigo); ?></p>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('medicamentos.edit', $medicamento->id)); ?>" 
                    class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg flex items-center">
                    <i class="fas fa-edit mr-2"></i> Editar
                </a>
                <a href="<?php echo e(route('medicamentos.index')); ?>" 
                    class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Volver
                </a>
            </div>
        </div>
        
        <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Columna Izquierda - Imagen e Info Básica -->
            <div class="md:col-span-1">
                <div class="bg-gray-50 p-4 rounded-lg border">
                    <div class="flex justify-center mb-4">
                        <img src="<?php echo e(asset('storage/'.$medicamento->imagen)); ?>" alt="<?php echo e($medicamento->nombre); ?>" 
                            class="h-48 w-48 object-contain rounded-lg border">
                            
                    </div>
                    
                    <div class="space-y-3">
                        <div>
                            <h3 class="font-medium text-gray-700">Nombre Comercial</h3>
                            <p class="text-lg font-semibold"><?php echo e($medicamento->nombre); ?></p>
                        </div>
                        
                        <div>
                            <h3 class="font-medium text-gray-700">Presentación</h3>
                            <p><?php echo e($medicamento->presentacion); ?></p>
                        </div>
                        
                        <div>
                            <h3 class="font-medium text-gray-700">Laboratorio</h3>
                            <p><?php echo e($medicamento->laboratorio); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Columna Central - Stock y Precios -->
            <div class="md:col-span-1">
                <div class="bg-gray-50 p-4 rounded-lg border h-full">
                    <h3 class="text-lg font-semibold mb-4 flex items-center">
                        <i class="fas fa-boxes mr-2"></i> Inventario
                    </h3>
                    
                    <div class="space-y-4">
                        <div>
                            <div class="flex justify-between items-center mb-1">
                                <span class="font-medium">Stock Actual</span>
                                <span class="font-bold <?php echo e($medicamento->stock <= $medicamento->stock_minimo ? 'text-red-600' : 'text-green-600'); ?>">
                                    <?php echo e($medicamento->stock); ?> unidades
                                </span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2.5">
                                <div class="bg-<?php echo e($medicamento->stock <= $medicamento->stock_minimo ? 'red' : 'green'); ?>-600 h-2.5 rounded-full" 
                                    style="width: <?php echo e(min(100, ($medicamento->stock / ($medicamento->stock_minimo + 10)) * 100)); ?>%"></div>
                            </div>
                            <div class="text-xs text-gray-500 mt-1">Stock mínimo: <?php echo e($medicamento->stock_minimo); ?> unidades</div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-white p-3 rounded-lg border">
                                <h4 class="text-sm font-medium text-gray-500">Precio Compra</h4>
                                <p class="text-lg font-semibold">$<?php echo e(number_format($medicamento->precio_compra, 2)); ?></p>
                            </div>
                            <div class="bg-white p-3 rounded-lg border">
                                <h4 class="text-sm font-medium text-gray-500">Precio Venta</h4>
                                <p class="text-lg font-semibold">$<?php echo e(number_format($medicamento->precio_venta, 2)); ?></p>
                            </div>
                        </div>
                        
                        <div class="bg-white p-3 rounded-lg border">
                            <h4 class="text-sm font-medium text-gray-500">Margen de Ganancia</h4>
                            <p class="text-lg font-semibold">
                                $<?php echo e(number_format($medicamento->precio_venta - $medicamento->precio_compra, 2)); ?>

                                <span class="text-sm text-green-600">
                                    (<?php echo e(number_format((($medicamento->precio_venta - $medicamento->precio_compra) / $medicamento->precio_compra * 100), 2)); ?>%)
                                </span>
                            </p>
                        </div>
                        
                        <div>
                            <h4 class="font-medium text-gray-700">Lote</h4>
                            <p><?php echo e($medicamento->lote); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Columna Derecha - Caducidad y Ventas -->
            <div class="md:col-span-1">
                <div class="bg-gray-50 p-4 rounded-lg border h-full">
                    <h3 class="text-lg font-semibold mb-4 flex items-center">
                        <i class="fas fa-calendar-alt mr-2"></i> Caducidad
                    </h3>
                    
                    <?php
                        $diasParaCaducar = now()->diffInDays($medicamento->fecha_caducidad, false);
                    ?>
                    
                    <div class="mb-4">
                        <div class="flex justify-between items-center mb-1">
                            <span class="font-medium">Fecha de Caducidad</span>
                            <span class="font-bold <?php echo e($diasParaCaducar <= 0 ? 'text-red-600' : ($diasParaCaducar <= 30 ? 'text-orange-600' : 'text-green-600')); ?>">
                                <?php echo e($medicamento->fecha_caducidad->format('d/m/Y')); ?>

                            </span>
                        </div>
                        <div class="text-sm <?php echo e($diasParaCaducar <= 0 ? 'text-red-600' : ($diasParaCaducar <= 30 ? 'text-orange-600' : 'text-green-600')); ?>">
                            <?php if($diasParaCaducar <= 0): ?>
                                <i class="fas fa-exclamation-triangle mr-1"></i> Caducado hace <?php echo e(abs($diasParaCaducar)); ?> días
                            <?php else: ?>
                                <i class="fas fa-clock mr-1"></i> Caduca en <?php echo e($diasParaCaducar); ?> días
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h4 class="font-medium text-gray-700">Requiere Receta</h4>
                        <p>
                            <?php if($medicamento->requiere_receta): ?>
                                <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm">
                                    <i class="fas fa-check-circle mr-1"></i> Sí
                                </span>
                            <?php else: ?>
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm">
                                    <i class="fas fa-times-circle mr-1"></i> No
                                </span>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <div class="mb-4">
                        <h4 class="font-medium text-gray-700">Descripción</h4>
                        <p class="text-gray-700"><?php echo e($medicamento->descripcion ?? 'N/A'); ?></p>
                    </div>
                    
                    <div>
                        <h4 class="font-medium text-gray-700">Registro</h4>
                        <p class="text-sm text-gray-500">
                            Creado: <?php echo e($medicamento->created_at->format('d/m/Y H:i')); ?><br>
                            Actualizado: <?php echo e($medicamento->updated_at->format('d/m/Y H:i')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Pestañas para Historial -->
        <div class="border-t">
            <div class="px-6">
                <nav class="flex space-x-4" aria-label="Tabs">
                    <button x-data="{ tab: 'ventas' }" @click="tab = 'ventas'" 
                        :class="{ 'border-blue-500 text-blue-600': tab === 'ventas', 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300': tab !== 'ventas' }"
                        class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                        Historial de Ventas
                    </button>
                    <button x-data="{ tab: 'ventas' }" @click="tab = 'alertas'" 
                        :class="{ 'border-blue-500 text-blue-600': tab === 'alertas', 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300': tab !== 'alertas' }"
                        class="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                        Alertas Generadas
                    </button>
                </nav>
            </div>
            <div class="px-6 py-4">
                <!-- Contenido de pestañas -->
                <div x-data="{ tab: 'ventas' }">
                    <!-- Pestaña de Ventas -->
                    <div x-show="tab === 'ventas'">
                        <?php if($ventas->isEmpty()): ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-shopping-cart text-3xl mb-2"></i>
                                <p>No hay registros de ventas para este medicamento</p>
                            </div>
                        <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Venta</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cantidad</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Unitario</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($venta->created_at->format('d/m/Y H:i')); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <a href="<?php echo e(route('ventas.show', $venta->venta_id)); ?>" class="text-blue-600 hover:underline">
                                                    <?php echo e($venta->venta->codigo); ?>

                                                </a>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                <?php echo e($venta->cantidad); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                $<?php echo e(number_format($venta->precio_unitario, 2)); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                $<?php echo e(number_format($venta->subtotal, 2)); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                <?php echo e($ventas->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Pestaña de Alertas -->
                    <div x-show="tab === 'alertas'" x-cloak>
                        <?php if($alertas->isEmpty()): ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-bell-slash text-3xl mb-2"></i>
                                <p>No hay alertas generadas para este medicamento</p>
                            </div>
                        <?php else: ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $alertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="bg-white p-4 rounded-lg border <?php echo e($alerta->resuelta ? 'border-gray-200' : ($alerta->tipo === 'caducidad' ? 'border-orange-200 bg-orange-50' : 'border-red-200 bg-red-50')); ?>">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <h4 class="font-medium flex items-center">
                                                <?php if($alerta->tipo === 'caducidad'): ?>
                                                    <i class="fas fa-calendar-times text-orange-500 mr-2"></i>
                                                    Alerta de Caducidad
                                                <?php else: ?>
                                                    <i class="fas fa-box-open text-red-500 mr-2"></i>
                                                    Alerta de Stock
                                                <?php endif; ?>
                                            </h4>
                                            <p class="text-sm text-gray-600 mt-1"><?php echo e($alerta->observaciones); ?></p>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo e($alerta->created_at->format('d/m/Y H:i')); ?>

                                        </div>
                                    </div>
                                    <div class="mt-2 flex justify-between items-center">
                                        <span class="text-xs px-2 py-1 rounded-full 
                                            <?php echo e($alerta->resuelta ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo e($alerta->resuelta ? 'Resuelta' : 'Pendiente'); ?>

                                        </span>
                                        <?php if(!$alerta->resuelta): ?>
                                        <form action="<?php echo e(route('alertas.resolve', $alerta->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded hover:bg-blue-200">
                                                Marcar como resuelta
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="mt-4">
                                <?php echo e($alertas->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\medic-storage\medic-storage\resources\views/medicamentos/show.blade.php ENDPATH**/ ?>